package SkillBox;

public class Product {
    private int price;
    private String name;
    private static int count;

    public Product(int price, String name) {
        this.price = price;
        this.name = name;
        count++;
    }

    public static int getCount() {
        return count;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getName() {
        return name;
    }
}
