package SkillBox;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Кофе-машина - Иван Карелкин" + "\n" + "Внесено средств: ");

        int moneyAmount = new Scanner(System.in).nextInt();

        List<String> lines = null;
        try {
            lines = Files.readAllLines(Path.of("C:\\Projects\\job4j_design\\src\\main\\java\\SkillBox\\drinks.txt"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        ArrayList<Product> products = new ArrayList<>();
        for (String line : lines) {
            String[] items = line.split("\s+");
            if (items.length != 2) {
                throw new IllegalArgumentException("Отсутствует наименование или цена напитка");
            }
            int price = Integer.parseInt(items[1]);
            products.add(new Product(price, items[0]));
        }

        System.out.println("Loader " + Product.getCount() + " products");
        boolean canBuyAnything = false;

        for (Product product : products) {
            if (moneyAmount >= product.getPrice()) {
                System.out.println("Вы можете купить " + product.getName());
                canBuyAnything = true;
            }
        }

        if (!canBuyAnything) {
            System.out.println("Недостаточно средств :( "
                               + "Изучайте Java и зарабатывайте много!");
        }
    }
}
