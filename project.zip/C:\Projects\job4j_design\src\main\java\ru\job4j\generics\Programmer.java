package ru.job4j.generics;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

public class Programmer extends Person {
    public Programmer(String name, int age, Date birthday) {
        super(name, age, birthday);
    }

    public void printInfo(Collection<Person> col) {
        for (Iterator<Person> it = col.iterator(); it.hasNext();) {
            Person next = it.next();
            System.out.println(next);
        }
    }
}
